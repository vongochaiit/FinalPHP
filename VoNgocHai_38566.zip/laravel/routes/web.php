<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// Route::get('/', function () {
//     return view('welcome');
// });
Route::resource('/','HomeController');
Route::resource('brand','brandsController')->middleware('adminLogin');
Route::resource('categorie','CategoriesController')->middleware('adminLogin');
Route::resource('customer','CustomersController')->middleware('adminLogin');
Route::resource('product','ProductsController');
Route::resource('order','OrdersController')->middleware('adminLogin');
Route::get('product/{id}/chitiet','ProductsController@chitiet')->name('product.chitiet');
Route::resource('cart','CartController')->middleware('userLogin');
Route::get('addCart/{id}','CartController@addCart')->name('addCart');
Route::post('/pay','CartController@pay')->middleware('userLogin');
 

Route::get('/main', 'MainController@index')->name('main');
Route::post('/main/checklogin', 'MainController@checklogin');
Route::get('main/successlogin', 'MainController@successlogin');
Route::get('main/logout', 'MainController@logout')->name('logout');
Route::get('indexCategories/{id}','HomeController@indexCategories')->name('indexCategories');
Route::get('indexBrands/{id}','HomeController@indexBrands')->name('indexBrands');
Route::resource('user','UserController');
