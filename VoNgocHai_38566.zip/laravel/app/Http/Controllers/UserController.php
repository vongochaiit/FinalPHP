<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\categories;
use App\Models\users;
use App\Models\customers;
use App\Models\brands;
use App\Models\products;
use Carbon\Carbon;
use Session;
class UserController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $products = products::all();
        $categories = categories::all();
         $brands = brands::all();
     return view('home.login.userLogin',compact('categories','products','brands'));

    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {    
         $this->validate($request, [
            'first_name'   => 'required',
            'last_name'   => 'required',
             'email'   => 'required',
               'postal_address'   => 'required',
                 'physical_address'   => 'required',
           
        ]);
         
         $users_id = users::insertGetId([
            'name'=>$request->name,
             'role'=>false,
            
             'password'=>bcrypt($request->password),
            'created_at'=>Carbon::now()->toDateTimeString()        
        ]);
          $users_data = users::findOrfail($users_id);
         $customers_data = new customers([
            'first_name'=>$request->first_name,
            'last_name' => $request->last_name,
               'email' => $request->email,
              
               'postal_address' => $request->postal_address,
               'physical_address' => $request->physical_address,
                'created_at' => Carbon::now()->toDateTimeString(),
               
        ]);
            $users_data->customers()->save($customers_data);
        

        Session::flash('thongdiep','Thêm dữ liệu thành công !');
        return redirect('/');
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        //
    }
}
