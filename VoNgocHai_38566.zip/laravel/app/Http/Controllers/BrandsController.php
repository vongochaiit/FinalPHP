<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\brands;
use App\Models\products;
use Carbon\Carbon;
use Session;
use Validator;

class BrandsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)

    {
        if (session::has('login')) {
         if ($request->searchName != null) {
            
            $brands = brands::where('name','like','%'.$request->searchName.'%')->get();
            return view('brands.index',compact('brands'));
        }
        $brands = brands::all();
        return view('brands.index',compact('brands'));
    }else{
        session::flash('loi','Bạn phải đăng nhập');
        return redirect('main');
    }
    
    
}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('brands.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $this->validate($request, [
            'name'   => 'required',
            'description'  => 'required'
        ]);
        $brands = new brands();
        $brands->name = $request->name;
        $brands->description = $request->description;
        $brands->created_at = Carbon::now()->toDateTimeString() ;
        $brands->save();
        Session::flash('thongdiep','Đã thêm dữ liệu thành công !');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        $brands = brands::findOrFail($id);
        return view('brands.show',compact('brands'));
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $brands = brands::findOrFail($id);
       return view('brands.edit',compact('brands'));
   }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $brand =brands::findOrFail($id);
        if ($brand) {
         $brand->name = $request->name;
         $brand->description = $request->description;
         $brand->updated_at = Carbon::now()->toDateTimeString();
         $brand->update();
     }else  {
       return back()->with('loi','Cập nhật dữ liệu không thành công');
   }
   return back()->with('thongdiep','Cập nhật dữ liệu thành công !');
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $brands = brands::findOrFail($id);
        if ($brands) {
          $brands->delete();
      } else {
          return back()->with('loi','Dữ liệu không tồn tại !');
      }
      return back()->with('thongdiep','Xóa thành công !');
  } 
}
