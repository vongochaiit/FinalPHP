<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\categories;
use App\Models\brands;
use App\Models\products;
use Carbon\Carbon;
use Session;

class ProductsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
       if (session::has('login')) {
        $brands = brands::all();
        $categories = categories::all();

        if ($request->searchName != null) {

            $products = products::where('product_name','like','%'.$request->searchName.'%')->get();
            return view('products.index',compact('products','categories','brands'));
        }

        if ($request->searchBrand != null) {

            $products = products::where('brand_id','like',$request->searchBrand)->get();
            return view('products.index',compact('products','categories','brands'));
        }

        $products = products::with('brands','categories')->get(); 
        return view('products.index',compact('products','categories','brands'));
    }else{
        session::flash('loi','Bạn phải đăng nhập !');
        return redirect('main');
    }
}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        $brands = brands::all();
        $categories = categories::all();
        return view('products.create',compact('brands','categories'));
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
       $this->validate($request, [

        'product_name'  => 'required',
        'description'  => 'required',
        'price'  => 'required',

        'images'  => 'required'
    ]);


       //dd($request);
       if($request->hasFile('images'))
       {


           $name=$request->images->getClientOriginalName();
           $request->images->move('img', $name); 


       }

       $products = new  products();
       $products->product_code = 'Post-'.Carbon::now()->toDateString();
       $products->product_name = $request->product_name;
       $products->description = $request->description;
       $products->price = $request->price;
       $products->brand_id = $request->brand_id;
       $products->categorie_id = $request->categorie_id;
       $products->images = $name;
       $products->save();

       Session::flash('thongdiep','Lưu thành công !');
       return back();

   }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $product = products::findOrFail($id);
        $brands = brands::pluck('name','id')->toArray();
        $categories = categories::pluck('name','id')->toArray();
        // $product = products::with('categories','brands')->get();
        return view('products.edit',compact('product','brands','categories'));
    }
    public function chitiet($id)
    {
        $product = products::findOrFail($id);
        $brands = brands::pluck('name','id')->toArray();
        $categories = categories::all();

        return view('products.chitiet',compact('product','brands','categories'));
    }
    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
     $products =products::findOrFail($id);
     if ($products) {
      if($request->hasFile('images'))
      {
                    //dd($request);
          $name=$request->images->getClientOriginalName();
          $request->images->move('img', $name); 

          $products->product_code = $products->product_code;
          $products->product_name = $request->product_name;
          $products->description = $request->description;
          $products->price = $request->price;
          $products->brand_id = $request->brand_id;
          $products->categorie_id = $request->categorie_id;
          $products->images =$name;
          $products->updated_at = Carbon::now()->toDateTimeString();
          $products->update();

      }else{
        $products->images = $products->images;
        $products->product_code = $products->product_code;
        $products->product_name = $request->product_name;
        $products->description = $request->description;
        $products->price = $request->price;
        $products->brand_id = $request->brand_id;
        $products->categorie_id = $request->categorie_id;

        $products->updated_at = Carbon::now()->toDateTimeString();
        $products->update();
    }
    return back()->with('thongdiep','Cập nhật dữ liệu thành công !');
}
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $products = products::findOrFail($id);
        if ($products) {
          $products->delete();
      } else {
          return back()->with('loi','Dữ liệu không tồn tại');
      }
      return back()->with('thongdiep','Xóa thành công !');
  }
}
