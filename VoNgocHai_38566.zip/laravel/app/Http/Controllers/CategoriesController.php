<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\categories;
use Carbon\Carbon;
use Session;

class CategoriesController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index(Request $request)
    {
       if (session::has('login')) {
           if ($request->seacrhName != null) {
            
            $categories = categories::where('name','like','%'.$request->seacrhName.'%')->get();
            return view('categories.index',compact('categories'));
        }
        $categories = categories::all();
        return view('categories.index',compact('categories'));
    }else{
        session::flash('loi','Bạn phải đăng nhập !');
        return redirect('main');
    }
}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        return view('categories.create');
    }   

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {   
         $this->validate($request, [
            'name'   => 'required',
            'description'  => 'required'
        ]);
        $categories = new categories();
        $categories->name = $request->name;
        $categories->description = $request->description;
        $categories->created_at = Carbon::now()->toDateTimeString() ;
        $categories->save();
        Session::flash('thongdiep','Thêm dữ liệu thành công');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        $categories = categories::findOrFail($id);
        return view('categories.edit',compact('categories'));
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
      $categories =categories::findOrFail($id);
      if ($categories) {
         $categories->name = $request->name;
         $categories->description = $request->description;
         $categories->updated_at = Carbon::now()->toDateTimeString();
         $categories->update();
     }else  {
       return back()->with('loi','Cập nhật dữ liệu thất bại');
   }
   return back()->with('thongdiep','Cập nhật dữ liệu thành công !');
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
     $categories = categories::findOrFail($id);
     if ($categories) {
      $categories->delete();
  } else {
      return back()->with('loi','Dữ liệu không tồn tại');
  }
  return back()->with('thongdiep','Xóa thành công');
}
}
