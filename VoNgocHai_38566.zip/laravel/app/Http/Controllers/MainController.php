<?php

namespace App\Http\Controllers;
use Validator;
use Auth;
use Session;
use Illuminate\Http\Request;

class MainController extends Controller
{
	function index()
	{
		return view('login');
	}
	function checklogin(Request $request)
	{
		$this->validate($request, [
			'name'   => 'required',
			'password'  => 'required|alphaNum|min:3'
		]);

		// $user_data = array(
		// 	'name'  => $request->get('name'),
		// 	'password' => $request->get('password')
		// );
		// 
		$name = $request['name'];
      $password = $request['password'];
		
		if (Auth::attempt(['name'=>$name,'password'=>$password,'role'=>true])) {
            //$users = Auth::user();
          
          //Session::put('id',$customers);
          Session::put('login',Auth::user()->name);
         //dd($customers->id);
          return redirect('order');
        }
        if (Auth::attempt(['name'=>$name,'password'=>$password,'role'=>false])) {
        	Session::put('login',Auth::user()->name);
         //dd($customers->id);
          return redirect('/');
        }
		else
		{
			return back()->with('error', 'Emai hoặc mật khẩu không đúng !');
		}

	}

	function successlogin()
	{
		return view('layouts.main');
	}

	function logout()
	{
		Auth::logout();
		session::forget('login');
		return redirect('/');
	}
}
