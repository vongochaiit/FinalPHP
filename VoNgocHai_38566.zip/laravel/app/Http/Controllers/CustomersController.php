<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\customers;
use App\Models\users;
use Carbon\Carbon;
use Session;

class CustomersController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index( Request $request)
    {
       if (session::has('login')) {
        if ($request->searchName != null) {
            
            $customers = customers::where('last_name','like','%'.$request->searchName.'%')->get();
            return view('customers.index',compact('customers'));
        }
        $customers = customers::all();
         // $customers->full_name = $request->first_name+$request->last_name;
        return view('customers.index',compact('customers'));
    }else{
        session::flash('loi','Bạn phải đăng nhập !');
        return redirect('main');
    }
}

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
     return view('customers.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {    
         $this->validate($request, [
            'first_name'   => 'required',
            'last_name'   => 'required',
             'email'   => 'required',
              'name'   => 'required',
               'password'   => 'required',
               'postal_address'   => 'required',
                 'physical_address'   => 'required',
           
        ]);
         
         $users_id = users::insertGetId([
            'name'=>$request->name,
             'role'=>false,
            
             'password'=>bcrypt($request->password),
            'created_at'=>Carbon::now()->toDateTimeString()        
        ]);
          $users_data = users::findOrfail($users_id);
         $customers_data = new customers([
            'first_name'=>$request->first_name,
            'last_name' => $request->last_name,
               'email' => $request->email,
              
               'postal_address' => $request->postal_address,
               'physical_address' => $request->physical_address,
                'created_at' => Carbon::now()->toDateTimeString(),
               
        ]);
            $users_data->customers()->save($customers_data);
        

        Session::flash('thongdiep','Thềm dữ liệu thành công !');
        return back();
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
       $customers = customers::findOrFail($id);
       return view('customers.edit',compact('customers'));
   }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $customers =customers::findOrFail($id);
        if ($customers) {
            $customers->first_name = $request->first_name;
            $customers->last_name = $request->last_name;
            $customers->email = $request->email;
            $customers->postal_address = $request->postal_address;
            $customers->physical_address = $request->physical_address;
            $customers->updated_at = Carbon::now()->toDateTimeString();
            $customers->update();
        }else  {
           return back()->with('loi','Cập nhật dữ liệu thất bại !');
       }
       return back()->with('thongdiep','Cập nhật dữ liệu thành công !');
   }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $customers = customers::findOrFail($id);
        if ($customers) {
          $customers->delete();
      } else {
          return back()->with('loi','du lieu khong ton tai');
      }
      return back()->with('thongdiep','xoa thanh cong');
  }
}
