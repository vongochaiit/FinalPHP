<?php

namespace App\Http\Controllers;

use Illuminate\Support\Facades\Redirect;
use Illuminate\Http\Request;
use App\Models\products;
use Cart;
use App\Models\orders;
use App\Models\orders_details;
use Carbon\Carbon;
use App\Models\customers;
use Auth;

class CartController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    
    public function index()
    {
        $customer = customers::Where('users_id',Auth::user()->id)->pluck('last_name','id');
        $cart =Cart::content();
        //dd($cart);
        return view('home.cart',compact('cart','customer'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }
    public function pay( Request $request  )
    {
        $pay = Cart::content();
        $order_id = orders::insertGetId([
            'order_number' => rand(),
            // 'isdelete'=>false,
            'transaction_date' => Carbon::now()->toDateTimeString(),
            'status' => 'Chưa giao',
            'total_amount' => str_replace(',', '', Cart::total()),
            'customer_id' => $request->customer_id,
            'created_at' => Carbon::now()->toDateTimeString(),
            'updated_at' => Carbon::now()->toDateTimeString()
        ]); 
        $orders_data = orders::findOrFail($order_id);
        //dd($request);  
        if (count($pay) > 0) {
            foreach ($pay as $key => $item) {
                $orders_detail_id = orders_details::insertGetId([
                    'quantity' => $item->qty,
                    'price' => $item->price,
                    'sub_toal' => $item->qty *$item->price ,
                    'order_id' => $order_id,
                    'product_id' =>$item->id,
                    'created_at' => Carbon::now()->toDateTimeString(),
                    'updated_at' => Carbon::now()->toDateTimeString()
                ]);
                $orders_detail_data = orders_details::findOrFail($orders_detail_id);
            }
        }
        Cart::destroy();
        
        return back()->with('thongbao','Đã mua hàng thành công');
    }
    

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */

    public function update(Request $request, $id)
    {
        //dd($request);
     
     if($request->cong ){
         
               //dd($request->qyt);
        $a = $request->qyt+1;
        
        Cart::update($id,$a);
        return back();
        
    }

    if($request->tru){
        if($request->qty == 1){
            return back()->with('loi','Số lượng phải lớn hơn 0');
        }else{
            $a = $request->qyt-1;
            Cart::update($id,$a);
            return back();
        }
    }
}

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
         Cart::remove($id);
        return back()->with('thongbao','Xóa thành công !');
    }
    public function addCart($id,Request $request)
    {
        $products = products::find($id);
        if($request->qty){
            $qty = $request->qty;
        }else{
         $qty = 1; 

     }
     if($request->promotional>0){
        $price = $products->promotional;
    }else{
     $price = $products->price;
 }
 $cart = ['id'=>$id,'name'=>$products->product_name,'qty'=> $qty,'price'=>$price,'options'=>['img'=>$products->images]];
 
 Cart::add($cart);
        //dd(Cart::content());
 return back()->with('thongbao','Đã mua hàng '.$products->product_name.' thành công !');
}
}
