<?php $__env->startSection('title','Create order'); ?>
<?php $__env->startSection('content'); ?>
	
<div class="content">
        
        <div class="row">
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header ">
              	<a style="margin: 10px" href="<?php echo e(route('product.create')); ?> "class="btn btn-success">Create brand</a>	
                <h5 class="card-title">Product</h5>
                
              </div>
              <div class="card-body ">
		<div class="row">

			<?php if(Session::has('thongdiep')): ?>
					<div class="alert alert-primary col-12" style="margin: 10px" role="alert">
						 <p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
					</div>
				
			<?php endif; ?>
		</div>
		
		<?php echo e(Form::open(['route' => 'product.store', 'method' => 'post','enctype '=>'multipart/form-data'])); ?>

	
		<div class="form-group <?php echo e($errors->has('fullname') ?'has-error':''); ?>">
			<?php echo e(Form::label('name','Product name	:')); ?>

			<?php echo e(Form::text('product_name','',['class'=>'form-control'])); ?>

			<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		</div>
		<div class="form-group <?php echo e($errors->has('fullname') ?'has-error':''); ?>">
			<?php echo e(Form::label('Status:')); ?>

			<?php echo e(Form::text('status','',['class'=>'form-control'])); ?>

			<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		</div>
		
		<div class="form-group <?php echo e($errors->has('phone') ?'has-error':''); ?>">
		
			<?php echo e(Form::label('price :')); ?>

			<?php echo e(Form::number('price','',['class'=>'form-control'])); ?>

			<span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
		</div>
		<?php echo e(Form::label('Product :')); ?>

		
		<select class="form-control" name="categorie_id">
   
			
			    
			  <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <option value="<?php echo e($products->id); ?>" > 
			        <?php echo e($products->product_name); ?> 
			    </option>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
		</select>
		<div class="form-group <?php echo e($errors->has('phone') ?'has-error':''); ?>">
		<?php echo e(Form::label('Customers :')); ?>

		
		<select class="form-control" name="categorie_id">
   
			
			    
			  <?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <option value="<?php echo e($customers->id); ?>" > 
			        <?php echo e($customers->first_name); ?> 
			    </option>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
		</select>
		
		</div>
			<?php echo e(form::submit('Create',['class'=>'btn btn-primary'])); ?>

			<a style="margin: 10px" href="<?php echo e(route('product.index')); ?> "class="btn btn-success">Back brand</a>
		<?php echo e(Form::close()); ?>

	</div>
	
	          
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-history"></i> PHP LARAVEL
                </div>
              </div>
            </div>
          </div>
        </div>
      
      </div>
     
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>