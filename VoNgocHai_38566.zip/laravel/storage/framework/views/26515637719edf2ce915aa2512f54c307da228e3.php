<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">
    <title>Home | E-Shopper</title>
    <link href="source/css/bootstrap.min.css" rel="stylesheet">
    <link href="source/css/font-awesome.min.css" rel="stylesheet">
    <link href="source/css/prettyPhoto.css" rel="stylesheet">
    <link href="source/css/price-range.css" rel="stylesheet">
    <link href="source/css/animate.css" rel="stylesheet">
	<link href="source/css/main.css" rel="stylesheet">
	<link href="source/css/responsive.css" rel="stylesheet">
    <!--[if lt IE 9]>
    <script src="js/html5shiv.js"></script>
    <script src="js/respond.min.js"></script>
    <![endif]-->       
    <link rel="shortcut icon" href="source/images/ico/favicon.ico">
    <link rel="apple-touch-icon-precomposed" sizes="144x144" href="source/images/ico/apple-touch-icon-144-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="114x114" href="source/images/ico/apple-touch-icon-114-precomposed.png">
    <link rel="apple-touch-icon-precomposed" sizes="72x72" href="source/images/ico/apple-touch-icon-72-precomposed.png">
    <link rel="apple-touch-icon-precomposed" href="source/images/ico/apple-touch-icon-57-precomposed.png">
</head><!--/head-->

<body>
	<!-- phan header -->
  <?php echo $__env->make("home.component.header", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- phan ket thuc header -->
	<!-- phan slide -->
	 <?php echo $__env->make("home.component.slide", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- phan ket thuc slide -->
	
	<section>
		<div class="container">
			<div class="row">
				<div class="col-sm-3">
					<div class="left-sidebar">
						<!-- phan category -->
						 <?php echo $__env->make("home.component.category", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- phan ket thuc category -->
						<!-- phan brand	 -->
						 <?php echo $__env->make("home.component.brand", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
						<!-- phan ket thuc brand -->
					</div>
				</div>
				
				<div class="col-sm-9 padding-right" style="float: left;">
					<!--features_items-->
						<h2 class="title text-center">Features Items</h2>
						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<div class="col-md-4" >
							
 								
										<div class="productinfo text-center">	
											<img src="<?php echo asset("/img/$products->images"); ?>" alt="" />
											<h2>$<?php echo e($products->price); ?></h2>
											<p><?php echo e($products->name); ?></p>
											<a href="<?php echo e(route('addCart',['id'=>$products->id])); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Add to cart</a>
											<a href="<?php echo e(route('product.chitiet',$products->id)); ?>" class="btn btn-default add-to-cart"><i class="fa fa-shopping-cart"></i>Details</a>	
										</div>
									
								</div>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
						</div>	
					
					<!--features_items-->
					
					
				</div>
			</div>
		</div>
	</section>
	
	<!-- phan footer -->
	<?php echo $__env->make("home.component.footer", \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
	<!-- phan ket thuc footer -->
	

  
    <script src="source/js/jquery.js"></script>
	<script src="source/js/bootstrap.min.js"></script>
	<script src="source/js/jquery.scrollUp.min.js"></script>
	<script src="source/js/price-range.js"></script>
    <script src="source/js/jquery.prettyPhoto.js"></script>
    <script src="source/js/main.js"></script>
</body>
</html>