<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="source/images/favicon.png">
  <title>
    Welcome to FlatShop
  </title>
  <link href="<?php echo e(asset('source/css/bootstrap.css')); ?>" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,700,500italic,100italic,100' rel='stylesheet' type='text/css'>
  <link href="<?php echo e(asset('source/css/font-awesome.min.css')); ?>" rel="stylesheet">
  <link rel="stylesheet" href="<?php echo e(asset('source/css/flexslider.css')); ?>" type="text/css" media="screen"/>
  <link href="<?php echo e(asset('source/css/style.css')); ?>" rel="stylesheet">
</head>
<body>
  <div class="wrapper">

    <?php echo $__env->make('home.component.header', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
    <div class="clearfix">
    </div>
    <div class="container_fullwidth">
      <div class="container">
        <div class="row">

          <div class="col-md-3">
      
          <?php echo $__env->make('home.component.category', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>

            <div class="clearfix">
            </div>
            
            <?php echo $__env->make('home.component.brand', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="clearfix">
            </div>
           
           
          </div>
          <div class="col-md-9">
           
           <?php echo $__env->make('home.component.slide', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
            <div class="clearfix">
            </div>
            <div class="products-grid">
              <div class="toolbar">
               
               
              </div>
              <div class="clearfix">
              </div>
              
                <?php echo $__env->make('home.component.product', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
                <?php echo $__env->yieldContent('content'); ?>
              <div class="clearfix">
              </div>
              
              <div class="toolbar">
                
              
              </div>
       
            </div>
            <div class="clearfix">
            </div>
          </div>
        </div>
      </div>
      <div class="clearfix">
      </div>
 
    </div>
  </div>
  <div class="clearfix">
  </div>
  
 <?php echo $__env->make('home.component.footer', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
<script type="text/javascript" src="<?php echo e(asset('source/js/jquery-1.10.2.min.js')); ?>">
</script>
<script type="text/javascript" src="<?php echo e(asset('source/js/jquery.easing.1.3.js')); ?>">
</script>
<script type="text/javascript" src="<?php echo e(asset('source/js/bootstrap.min.js')); ?>">
</script>
<script defer src="<?php echo e(asset('source/js/jquery.flexslider.js')); ?>">
</script>
<script type="text/javascript" src="<?php echo e(asset('source/js/jquery.sequence-min.js')); ?>">
</script>
<script type="text/javascript" src="<?php echo e(asset('source/js/jquery.carouFredSel-6.2.1-packed.js')); ?>">
</script>
<script type="text/javascript" src="<?php echo e(asset('source/js/script.min.js')); ?>" >
</script>
</body>
</html>