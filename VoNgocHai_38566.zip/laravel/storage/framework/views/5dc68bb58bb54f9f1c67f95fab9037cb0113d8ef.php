<?php $__env->startSection('title','Categories'); ?>
<?php $__env->startSection('content'); ?>


		
	<div class="content">
        
        <div class="row">
        	
			<?php if(Session::has('thongdiep')): ?>
					<div class="alert alert-primary" role="alert">
						 <p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
					</div>
				
			<?php endif; ?>
			<?php if(Session::has('loi')): ?>
					<div class="btn btn-dange" role="alert">
						 <p class=""><?php echo e(Session::get('loi')); ?></p>						
					</div>
				
			<?php endif; ?>
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header ">
              	<a style="margin: 10px" href="<?php echo e(route('product.create')); ?> "class="btn btn-success">Create brand</a>	
                <h5 class="card-title">Product</h5>
                
              </div>
              <div class="card-body ">
                
				<?php echo e(Form::open(['route' => ['product.index' ],'method' => 'get'])); ?>

			<!-- 	<select class="form-control" name="seachcategorie">
   
			<option value="null">categories</option>
			    
			  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <option value="<?php echo e($categories->id); ?>" > 
			        <?php echo e($categories->name); ?> 
			    </option>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
		</select> -->
		<div class="form-group col-6" style="float: left;">
			<?php echo e(Form::label('Brand :')); ?>

				<select style="float: left;" class="form-control" name="seachbrand">
   
			
			    <option value="null">Brand</option>
					  	<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					    <option value="<?php echo e($brands->id); ?>" > 
					        <?php echo e($brands->name); ?> 
					    </option>
					  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
		</select>
		</div>
		<div class="form-group col-6" style="float: left;">
			<?php echo e(Form::label('Name :')); ?>

			<?php echo e(Form::text('seachname','',['class'=>'form-control ','style'=>'float: left'])); ?>

		</div>
		
				
				<?php echo e(form::submit('Seach',['class'=>'btn btn-danger','style'=>'float: left'])); ?>

				<?php echo e(Form::close()); ?>

	<table class="table ">
		<thead>
			<th style="text-align:center;">STT</th>
			<th style="text-align:center;">Name</th>
			<th style="text-align:center;">Brand</th>
			<th style="text-align:center;">Description</th>
			<th >Action</th>
		</thead>
		<tbody style="margin-top: 100px">

			<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr  >
				<td style="text-align:center;"><?php echo e(++$key); ?></td>

				<td style="text-align:center;"><?php echo e($products->product_name); ?></td>	
				<td style="text-align:center;"><?php echo e($products->brands->name); ?></td>	
				<td style="text-align:center;"><?php echo e($products->description); ?></td>
				<td> 
				
					<img  style="position: absolute; width: 70px;height: 40px"  class="card-img-top" src="<?php echo asset("/img/$products->images"); ?>"   >

					

			
				</td>
				<td >

				
				<a href="<?php echo e(route('product.edit',$products->id)); ?>" style="float: left;" class="btn btn-primary">edit</a>
				<?php echo e(Form::open(['route' => ['product.destroy',$products->id ],'method' => 'Delete'])); ?>

				<?php echo e(form::submit('Delete',['class'=>'btn btn-danger','style'=>'float: left'])); ?>

				<?php echo e(Form::close()); ?>

			</tr>
			</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>
	</table>
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-history"></i> PHP LARAVEL
                </div>
              </div>
            </div>
          </div>
        </div>
      
      </div>
     
    </div>
	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>