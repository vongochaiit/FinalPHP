<?php $__env->startSection('title','Create customer'); ?>
<?php $__env->startSection('content'); ?>

<div class="content">

	<div class="row">
		<div class="col-md-12">
			<div class="card "  style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					
					
				</div>
				<div class="card-body ">
					<div class="row">

						<?php if(Session::has('thongdiep')): ?>
						<div class="alert alert-primary col-12" style="margin: 10px" role="alert">
							<p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
						</div>

						<?php endif; ?>
					</div>

					<?php echo e(Form::open(['route' => 'product.store', 'method' => 'post','enctype '=>'multipart/form-data'])); ?>


					<div class="form-group ">
						<p>Tên sản phẩm:</p>
						<?php echo e(Form::text('product_name','',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('product_name')); ?></span>
					</div>
					<div class="form-group ">
						<p>Mô tả:</p>
						<?php echo e(Form::text('description','',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('description')); ?></span>
					</div>
					
					<div class="">
						<p>Chọn hinh sảnh sản phẩm:</p>
						<input  name="images" type="file" class="form-control">
                         <span class="text-danger"><?php echo e($errors->first('images')); ?></span>

					</div>
					<div class="form-group ">

						<p style="padding-top: 10px;">Giá:</p>
						<?php echo e(Form::text('price','',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('price')); ?></span>
					</div>
					<div class="form-group ">
						<p>Hãng sản xuất:</p>
						<select class="form-control" name="brand_id">



							<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($brands->id); ?>" > 
								<?php echo e($brands->name); ?> 
							</option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   
							
						</select>
					</div>
					<div class="form-group ">
						<p>Danh mục:</p>
						<select class="form-control" name="categorie_id">



							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<option value="<?php echo e($categories->id); ?>" > 
								<?php echo e($categories->name); ?> 
							</option>
							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>   

						</select>

					</div>
					<?php echo e(form::submit('Lưu',['class'=>'btn btn-primary'])); ?>

					<a style="margin: 10px" href="<?php echo e(route('product.index')); ?> "class="btn btn-success">Danh sách </a>
					<?php echo e(Form::close()); ?>

				</div>


				
			</div>
		</div>
	</div>

</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>