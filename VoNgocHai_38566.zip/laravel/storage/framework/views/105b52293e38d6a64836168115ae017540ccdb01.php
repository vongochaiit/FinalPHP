 <div class="header">
      <div class="container">
        <div class="row">
          <div class="col-md-2 col-sm-2">
            <div class="logo">
              
                <img src="source/images/logo.png" alt="FlatShop">
           
            </div>
          </div>
          <div class="col-md-10 col-sm-10">
            <div class="header_top">
              <div class="row">
                <div class="col-md-3">
                  <ul class="option_nav">
                   
                  </ul>
                </div>
                <div class="col-md-6">
                  <ul class="topmenu">
                    <li>
                      <a href="#">
                        About Us
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        News
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        Service
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        Recruiment
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        Media
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        Support
                      </a>
                    </li>
                  </ul>
                </div>
                <div class="col-md-3">
                  <ul class="usermenu">
                    <?php if(Session::has('login')): ?>{
                      <li>
                        <a href="<?php echo e(route('logout')); ?>" class="log">
                        Logout
                      </a>
                    </li>
                  }<?php else: ?>{
                  <li>
                        <a href="<?php echo e(route('main')); ?>" class="log">
                        Login
                      </a>
                    </li>
                    <li>
                        <a href="<?php echo e(route('user.create')); ?>" class="reg">
                        Register
                      </a>
                    </li>
                }
                    <?php endif; ?>
                    
                  </ul>
                </div>
              </div>
            </div>
            <div class="clearfix">
            </div>
            <div class="header_bottom">
              <ul class="option">
                <li id="search" class="search">
                  <form>
                    <input class="search-submit" type="submit" value="">
                    <input class="search-input" placeholder="Enter your search term..." type="text" value="" name="search">
                  </form>
                </li>
                <li class="option-cart">
                  <i style="color: white"><?php echo e(Cart::count()); ?></i>
                  <a href="<?php echo e(route('cart.index')); ?>" class="cart-icon">
                    
                  
                  </a>

          
                </li>
              </ul>
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="sr-only">
                    Toggle navigation
                  </span>
                  <span class="icon-bar">
                  </span>
                  <span class="icon-bar">
                  </span>
                  <span class="icon-bar">
                  </span>
                </button>
              </div>
              <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                  <li class="active dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                      Home
                    </a>
               
                  </li>
                  <li>
                    <a href="#">
                      men
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      women
                    </a>
                  </li>
                  <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                      Fashion
                    </a>
                    
                  </li>
                  <li>
                    <a href="#">
                      gift
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      kids
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      blog
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      jewelry
                    </a>
                  </li>
                  <li>
                    <a href="#">
                      contact us
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>