<?php $__env->startSection('title','Create customer'); ?>
<?php $__env->startSection('content'); ?>
	
<div class="content">
        
        <div class="row">
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header ">
              	<a style="margin: 10px" href="<?php echo e(route('product.create')); ?> "class="btn btn-success">Create brand</a>	
                <h5 class="card-title">Product</h5>
                
              </div>
              <div class="card-body ">
		<div class="row">

			<?php if(Session::has('thongdiep')): ?>
					<div class="alert alert-primary col-12" style="margin: 10px" role="alert">
						 <p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
					</div>
				
			<?php endif; ?>
		</div>
		
		<?php echo e(Form::open(['route' => 'product.store', 'method' => 'post','enctype '=>'multipart/form-data'])); ?>

	
		<div class="form-group <?php echo e($errors->has('fullname') ?'has-error':''); ?>">
			<?php echo e(Form::label('name','Product name	:')); ?>

			<?php echo e(Form::text('product_name','',['class'=>'form-control'])); ?>

			<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		</div>
		<div class="form-group <?php echo e($errors->has('fullname') ?'has-error':''); ?>">
			<?php echo e(Form::label('name','Description:')); ?>

			<?php echo e(Form::text('description','',['class'=>'form-control'])); ?>

			<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		</div>
		<div class="form-group">
			<?php echo e(Form::label('Image Product')); ?>

			<input multiple="multiple" name="images" type="file" class="form-control">
			
			
		</div>
		<div class="form-group <?php echo e($errors->has('phone') ?'has-error':''); ?>">
		
			<?php echo e(Form::label('price :')); ?>

			<?php echo e(Form::text('price','',['class'=>'form-control'])); ?>

			<span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
		</div>
		<div class="form-group <?php echo e($errors->has('phone') ?'has-error':''); ?>">
		<?php echo e(Form::label('Brand :')); ?>

		<select class="form-control" name="brand_id">
   
			
			    
			  <?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <option value="<?php echo e($brands->id); ?>" > 
			        <?php echo e($brands->name); ?> 
			    </option>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
		</select>
		</div>
		<div class="form-group <?php echo e($errors->has('phone') ?'has-error':''); ?>">
		<?php echo e(Form::label('Categorie :')); ?>

		<select class="form-control" name="categorie_id">
   
			
			    
			  <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			    <option value="<?php echo e($categories->id); ?>" > 
			        <?php echo e($categories->name); ?> 
			    </option>
			  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
		</select>
		
		</div>
			<?php echo e(form::submit('Create',['class'=>'btn btn-primary'])); ?>

			<a style="margin: 10px" href="<?php echo e(route('product.index')); ?> "class="btn btn-success">Back brand</a>
		<?php echo e(Form::close()); ?>

	</div>
	
	          
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-history"></i> PHP LARAVEL
                </div>
              </div>
            </div>
          </div>
        </div>
      
      </div>
     
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>