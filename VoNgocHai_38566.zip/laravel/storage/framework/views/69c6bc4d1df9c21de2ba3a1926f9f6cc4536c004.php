<?php $__env->startSection('title','Categories'); ?>
<?php $__env->startSection('content'); ?>



<div class="content">
	
	<div class="row">
		
		<?php if(Session::has('thongdiep')): ?>
		<div class="alert alert-primary" role="alert">
			<p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
		</div>
		
		<?php endif; ?>
		<?php if(Session::has('loi')): ?>
		<div class="btn btn-dange" role="alert">
			<p class=""><?php echo e(Session::get('loi')); ?></p>						
		</div>
		
		<?php endif; ?>
		<div class="col-md-12">
			<div class="card "style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
						
					<h5 class="card-title">Danh sách khách hàng</h5>
					
				</div>
				<div class="card-body ">
					<?php echo e(Form::open(['route' => ['customer.index' ],'method' => 'get'])); ?>

					
					<div class="form-group col-6" style="float: left;">
						<p>Tên khách hàng:</p>
						<?php echo e(Form::text('searchName','',['class'=>'form-control ','style'=>'float: left'])); ?>

					</div>
					<?php echo e(form::submit('Tìm kiếm',['class'=>'btn btn-primary','style'=>'margin-top:37px;'])); ?>

					<?php echo e(Form::close()); ?>

					<table class="table ">
						<thead>
							<th style="text-align:center;">STT</th>
							<th style="text-align:center;">Họ</th>
							<th style="text-align:center;">Tên</th>
							<th style="text-align:center;">Email</th>
							<th style="text-align:center;">Mã bưu điện</th>
							<th style="text-align:center;">Địa chỉ</th>
							<th >Hành động</th>
						</thead>
						<tbody>

							<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td style="text-align:center;"><?php echo e(++$key); ?></td>
								<td style="text-align:center;"><?php echo e($customers->first_name); ?></td>	
								<td style="text-align:center;"><?php echo e($customers->last_name); ?></td>
								<td style="text-align:center;"><?php echo e($customers->email); ?></td>
								<td style="text-align:center;"><?php echo e($customers->postal_address); ?></td>
								<td style="text-align:center;"><?php echo e($customers->physical_address); ?></td>
								<td >

									
								
									<?php echo e(Form::open(['route' => ['customer.destroy',$customers->id ],'method' => 'Delete'])); ?>

									<?php echo e(form::submit('Xóa',['class'=>'btn btn-danger','style'=>'margin-left: 15px'])); ?>

									<?php echo e(Form::close()); ?>

								</tr>
							</tr>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</tbody>
					</table>
					
				</div>
				
			</div>
		</div>
	</div>
	
</div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>