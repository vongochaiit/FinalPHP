<?php $__env->startSection('title','Show brands'); ?>
<?php $__env->startSection('content'); ?>
<br>
<th>dwas</th>
<div class="container">
	<p><?php echo e($brands->name); ?></p>
	<p><?php echo e($brands->description); ?></p>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>