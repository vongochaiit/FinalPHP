  <div class="category leftbar">
              <h3 class="title">
                Categories
              </h3>
              <ul>
               	<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
				<li><a href="<?php echo e(route('indexCategories',[$categories->id])); ?>"><?php echo e($categories->name); ?>	</a></li>

                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>