<?php $__env->startSection('title','Create brand'); ?>
<?php $__env->startSection('content'); ?>

<div class="content">
	
	<div class="row">
		<div class="col-md-12">
			<div class="card " style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					
					
				</div>
				<div class="card-body ">
					<div class="row">

						<?php if(Session::has('thongdiep')): ?>
						<div class="alert alert-primary col-12" style="margin: 10px" role="alert">
							<p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
						</div>
						
						<?php endif; ?>
					</div>
					
					
					
					<?php echo e(Form::model($brands,['route' => ['brand.update',$brands->id ],'method' => 'put'])); ?>

					<div class="form-group ">
						<p>Hãng sản xuất:</p>
						<?php echo e(Form::text('name',$brands->name,['class'=>'form-control'])); ?>

						
					</div>
					<div class="form-group ">
						
						<p>Mô tả:</p>
						<?php echo e(Form::text('description',$brands->description,['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
					</div>
					
					<?php echo e(form::submit('Cập nhật',['class'=>'btn btn-primary'])); ?>

					<a style="margin: 10px" href="<?php echo e(route('brand.index')); ?> "class="btn btn-success">Trở lại </a>
					<?php echo e(Form::close()); ?>

				</div>


				
				
				
			</div>
		</div>
	</div>
	
</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>