<?php $__env->startSection('title','Categories'); ?>
<?php $__env->startSection('content'); ?>



<div class="content">

	<div class="row">

		<?php if(Session::has('thongdiep')): ?>
		<div class="alert alert-primary" role="alert">
			<p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
		</div>

		<?php endif; ?>
		<?php if(Session::has('loi')): ?>
		<div class="btn btn-dange" role="alert">
			<p class=""><?php echo e(Session::get('loi')); ?></p>						
		</div>

		<?php endif; ?>
		<div class="col-md-12" >
			<div class="card " style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					<a style="margin: 10px ;color: black;" href="<?php echo e(route('product.create')); ?> "class="btn btn-primary">Thêm sản phẩm</a>	
					<h5 class="card-title">Danh sách sản phẩm</h5>

				</div>
				

				<?php echo e(Form::open(['route' => ['product.index' ],'method' => 'get'])); ?>

				
				<div class="form-group col-4" style="float: left;">
					<p>Hãng sản xuất:</p>
					<select style="float: left;" class="form-control" name="searchBrand">
						<option value="null"> </option>
						<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<option value="<?php echo e($brands->id); ?>" > 
							<?php echo e($brands->name); ?> 
						</option>
						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
					</select>
				</div>

				<div class="form-group col-4" style="float: left;">
					<p>Tên sản  phẩm:</p>
					<?php echo e(Form::text('seacrhName','',['class'=>'form-control ','style'=>'float: left'])); ?>

				</div>

				<div class="form-group col-4" style="float: left; margin-top: 26px">
					<?php echo e(form::submit('Tìm kiếm',['class'=>'btn btn-primary','style'=>'float: left'])); ?>

					<?php echo e(Form::close()); ?>

				</div>

				<table class="table ">
					<thead>
						<th style="text-align:center;">STT</th>
						<th style="text-align:center;">Tên sản phẩm</th>
						<th style="text-align:center;">Hãng sản xuất</th>
						<th style="text-align:center;">Mô tả</th>
						<th >Hình ảnh</th>
						<th >Hành động</th>
					</thead>
					<tbody style="margin-top: 100px">

						<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
						<tr  >
							<td style="text-align:center;"><?php echo e(++$key); ?></td>
							<td style="text-align:center;"><?php echo e($products->product_name); ?></td>	
							<td style="text-align:center;"><?php echo e($products->brands->name); ?></td>	
							<td style="text-align:center;"><?php echo e($products->description); ?></td>
							<td> 

								<img  style=" width: 70px;height: 40px; "  src="<?php echo asset("/img/$products->images"); ?>"   >

							</td>
							<td >

								<a href="<?php echo e(route('product.edit',$products->id)); ?>" style="float: left; margin-right: 20px;" class="btn btn-primary">Sữa</a>
								<?php echo e(Form::open(['route' => ['product.destroy',$products->id ],'method' => 'Delete'])); ?>

								<?php echo e(form::submit('Xóa',['class'=>'btn btn-danger','style'=>'float: left'])); ?>

								<?php echo e(Form::close()); ?>

							</tr>
						</tr>

						<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

					</tbody>
				</table>
			</div>
			
		</div>
	</div>
</div>

</div>

</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>