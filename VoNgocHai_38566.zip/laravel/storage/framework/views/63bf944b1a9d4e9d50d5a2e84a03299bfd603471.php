<?php $__env->startSection('title','Create customer'); ?>
<?php $__env->startSection('content'); ?>

<div class="content">
	
	<div class="row">
		<div class="col-md-12">
			<div class="card " style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					
					<h5 class="card-title">Thêm khách hàng</h5>
					
				</div>
				<div class="card-body ">
					<div class="row">

						<?php if(Session::has('thongdiep')): ?>
						<div class="alert alert-primary col-12" style="margin: 10px" role="alert">
							<p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
						</div>
						
						<?php endif; ?>
					</div>
					<?php echo e(Form::open(['route' => 'customer.store', 'method' => 'post'])); ?>

					<div class="form-group ">
						<p>Họ :</p>
						<?php echo e(Form::text('first_name','',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('first_name')); ?></span>
					</div>
					<div class="form-group ">
					<p>Tên :</p>
						<?php echo e(Form::text('last_name','',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('last_name')); ?></span>
					</div>
					<div class="form-group ">
					<p>Email :</p>
						<?php echo e(Form::text('email','',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('email')); ?></span>
					</div>
					<div class="form-group ">
					<p>Tài khoản :</p>
						<?php echo e(Form::text('name','',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
					</div>

					<div class="form-group ">
						<p>Mật khẩu :</p>
						<?php echo e(Form::password('password',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('password')); ?></span>
					</div>

					<div class="form-group ">
						
						<p>Mã bưu điện :</p>
						<?php echo e(Form::text('postal_address','',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('postal_address')); ?></span>
					</div>
					<div class="form-group ">
						
						<p>Địa chỉ :</p>
						<?php echo e(Form::text('physical_address','',['class'=>'form-control'])); ?>

						<span class="text-danger"><?php echo e($errors->first('physical_address')); ?></span>
					</div>
					
					<?php echo e(form::submit('Thêm',['class'=>'btn btn-primary'])); ?>

					<a style="margin: 10px" href="<?php echo e(route('customer.index')); ?> "class="btn btn-success">Trở lại</a>
					<?php echo e(Form::close()); ?>

				</div>
				
			
			</div>
		</div>
	</div>
	
</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>