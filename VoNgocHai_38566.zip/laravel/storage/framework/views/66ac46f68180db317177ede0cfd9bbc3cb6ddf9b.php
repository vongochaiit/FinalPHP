	
	<?php $__env->startSection('title','Brand'); ?>
	<?php $__env->startSection('content'); ?>
	<div class="content">
		
		<div class="row">
			
			
			<div class="col-md-12">
				<div class="card "style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
					<div class="card-header ">
						
						<h5 class="card-title">Danh sách đơn đặt hàng</h5>
						<?php if(Session::has('thongdiep')): ?>
						<div class="alert alert-primary" role="alert">
							<p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
						</div>
						
						<?php endif; ?>
						<?php if(Session::has('loi')): ?>
						<div class="btn btn-dange" role="alert">
							<p class=""><?php echo e(Session::get('loi')); ?></p>						
						</div>
						
						<?php endif; ?>
					</div>
					<div class="card-body ">
						
			<table class="table ">
				<thead>
					<th style="text-align:center;">STT</th>
					<th style="text-align:center;">Tên khách hàng </th>
					<th style="text-align:center;">Mã Đặt Hàng</th>
					<th style="text-align:center;">Thành tiền </th>
					<th >Thao tác</th>
				</thead>
				<tbody>
					
					<?php $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orders): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<tr>
						<td style="text-align:center;"><?php echo e(++$key); ?></td>
						<td style="text-align:center;"> <?php echo e($orders->customers->last_name); ?> <?php echo e($orders->customers->first_name); ?></td>
						<!-- <td style="text-align:center;"><?php echo e(date('d-m-Y', strtotime($orders->order_number))); ?></td>	 -->
						<td style="text-align:center;"><?php echo e($orders->order_number); ?></td>
						<td style="text-align:center;"><?php echo e($orders->total_amount); ?></td>
						<td >
							
							
							<a href="<?php echo e(route('order.show',$orders->id)); ?>" style="float: left;margin-right: 10px" class="btn btn-primary">Chi tiết</a>
							<?php echo e(Form::open(['route' => ['order.destroy',$orders->id ],'method' => 'Delete'])); ?>

							<?php echo e(form::submit('Xóa',['class'=>'btn btn-danger','style'=>'float: left'])); ?>

							<?php echo e(Form::close()); ?>

						</tr>
					</tr>

					<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
					
				</tbody>
			</table>
		</div>
		
	</div>
</div>
</div>

</div>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>