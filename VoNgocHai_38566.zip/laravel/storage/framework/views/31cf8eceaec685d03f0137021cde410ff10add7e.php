<!DOCTYPE html>
<html lang="en">

<head>

  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
  <meta name="description" content="">
  <meta name="author" content="">

  <title>Shop Homepage - Start Bootstrap Template</title>

  <!-- Bootstrap core CSS -->
  <link href="<?php echo e(asset('vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

  <!-- Custom styles for this template -->
  <link href="<?php echo e(asset('css/shop-homepage.css')); ?>">

</head>

<body>

  <!-- Navigation -->
  <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
    <div class="container">
      <a class="navbar-brand" href="#">Start Bootstrap</a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse" id="navbarResponsive">
        <ul class="navbar-nav ml-auto">
          <li class="nav-item active">
            <a class="nav-link" href="#">Home
              <span class="sr-only">(current)</span>
            </a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">About</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="#">Services</a>
          </li>
          <li class="nav-item">
            <a class="nav-link" href="<?php echo e(route('cart.index')); ?>" title="<?php echo e(Cart::count()); ?>">gio hang</a>
          </li>
        </ul>
      </div>
    </div>
  </nav>

  <!-- Page Content -->
  <div class="container">

    <div class="row" style="margin-top: 50px">

      <div class="col-lg-3">

        <h1 class="my-4">Shop Name</h1>
        <div class="list-group">
          <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <a href="#" class="list-group-item"><?php echo e($categories->name); ?></a>
          
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

      </div>
      <!-- /.col-lg-3 -->

      <div class="col-lg-9">

        <div id="carouselExampleIndicators" class="carousel slide my-4" data-ride="carousel">
          <ol class="carousel-indicators">
            <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
            <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
          </ol>
          <div class="carousel-inner" role="listbox">
            <div class="carousel-item active">
              <img style="height: 320px;width: 100%" class="d-block img-fluid" src="https://media.vietteltelecom.vn/upload/ckfinder/images/626x351_km%20the%20n%E1%BA%A1p-10072019.jpg" alt="First slide">
            </div>
            <div class="carousel-item">
              <img style="height: 320px;width: 100%" class="d-block img-fluid" src="https://3gviettel.vn/wp-content/uploads/2019/09/khuyen-mai-viettel-ngay-20-9-2019.png" alt="Second slide">
            </div>
            <div class="carousel-item">
              <img style="height: 320px;width: 100%" class="d-block img-fluid" src="https://rangdong.com.vn/uploads/images/chuong-trinh-khuyen-mai/Chuong-trinh-khuyen-mai-2019-555x350.jpg" alt="Third slide">
            </div>
          </div>
          <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
          </a>
          <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
          </a>
        </div>

        <div class="row">
          <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <div class="col-lg-4 col-md-6 mb-4">
            <div class="card h-100">
             <?php $__currentLoopData = json_decode($products->images,true); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ka =>$image): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <img  style="z-index:<?php echo e(++$ka); ?>;position: absolute; width: 254px;height: 150px"  class="" src="<?php echo asset("/img/$image"); ?>"   >

          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?> 
              <a href="#"><img class="card-img-top" src="" alt=""></a>
              <div class="card-body" style="margin-top: 140px">
                <h4 class="card-title">
                  <a href="<?php echo e(route('product.chitiet',$products->id)); ?>"><?php echo e($products->product_name); ?></a>
                </h4>
                <h5>$<?php echo e($products->price); ?></h5>
                <p class="card-text"><?php echo e($products->description); ?></p>
              </div>
              <a href="<?php echo e(route('addCart',['id'=>$products->id])); ?>">Cart</a>
              <div class="card-footer">
                <small class="text-muted">&#9733; &#9733; &#9733; &#9733; &#9734;</small>
              </div>
            </div>
          </div>
          
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <!-- /.row -->

      </div>
      <!-- /.col-lg-9 -->

    </div>
    <!-- /.row -->

  </div>
  <!-- /.container -->

  <!-- Footer -->
  <footer class="py-5 bg-dark">
    <div class="container">
      <p class="m-0 text-center text-white">Copyright &copy; Your Website 2019</p>
    </div>
    <!-- /.container -->
  </footer>

  <!-- Bootstrap core JavaScript -->
  <script src="vendor/jquery/jquery.min.js"></script>
  <script src="vendor/bootstrap/js/bootstrap.bundle.min.js"></script>

</body>

</html>
