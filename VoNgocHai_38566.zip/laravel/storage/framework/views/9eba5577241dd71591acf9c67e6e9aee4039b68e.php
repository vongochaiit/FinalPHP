
<div class="row">
                <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $products): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="col-md-4 col-sm-6">
                  <div class="products">
                    <div class="thumbnail">
                      <a href="<?php echo e(route('product.chitiet',$products->id)); ?>">
                        <img src="<?php echo asset("/img/$products->images"); ?>" alt="Product Name">
                      </a>
                    </div>
                    <div class="productname">
                    <?php echo e($products->product_name); ?>

                    </div>
                    <h4 class="price">
                      <?php echo e($products->price); ?>$
                    </h4>
                    <div class="button_group">
                      <a href="<?php echo e(route('addCart',['id'=>$products->id])); ?>">
                      <button class="button add-cart" type="button">
                        Add To Cart
                      </button>
                      </a>
                      <button class="button compare" type="button">
                        <i class="fa fa-exchange">
                        </i>
                      </button>
                      <button class="button wishlist" type="button">
                        <i class="fa fa-heart-o">
                        </i>
                      </button>
                    </div>
                  </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           
              </div>
