<?php $__env->startSection('title','Create brand'); ?>
<?php $__env->startSection('content'); ?>
	
<div class="content">
        
        <div class="row">
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header ">
              	<a style="margin: 10px" href="<?php echo e(route('product.create')); ?> "class="btn btn-success">Create brand</a>	
                <h5 class="card-title">Product</h5>
                
              </div>
              <div class="card-body ">
		<div class="row">

			<?php if(Session::has('thongdiep')): ?>
					<div class="alert alert-primary" role="alert">
						 <p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
					</div>
				
			<?php endif; ?>
		</div>
		
		<?php echo e(Form::open(['route' => 'brand.store', 'method' => 'post'])); ?>

		<div class="form-group <?php echo e($errors->has('fullname') ?'has-error':''); ?>">
			<?php echo e(Form::label('name','Name:')); ?>

			<?php echo e(Form::text('name','',['class'=>'form-control'])); ?>

			<span class="text-danger"><?php echo e($errors->first('name')); ?></span>
		</div>
			<div class="form-group <?php echo e($errors->has('phone') ?'has-error':''); ?>">
		
			<?php echo e(Form::label('description :')); ?>

			<?php echo e(Form::text('description','',['class'=>'form-control'])); ?>

			<span class="text-danger"><?php echo e($errors->first('phone')); ?></span>
		</div>
			
			<?php echo e(form::submit('Create',['class'=>'btn btn-primary'])); ?>

			<a style="margin: 10px" href="<?php echo e(route('brand.index')); ?> "class="btn btn-success">Back brand</a>
		<?php echo e(Form::close()); ?>

	</div>
	
	          
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-history"></i> PHP LARAVEL
                </div>
              </div>
            </div>
          </div>
        </div>
      
      </div>
     
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>