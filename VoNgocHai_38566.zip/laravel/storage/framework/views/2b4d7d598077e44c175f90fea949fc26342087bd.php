 <div class="sidebar-wrapper" >
  <ul class="nav" >
    <li >
      <a href="<?php echo e(route('product.index')); ?>">
        <p >Danh mục sản phẩm</p>
    </a>
</li>

<li>
    <a href="<?php echo e(route('brand.index')); ?>">
        <p >Danh mục hãng sản xuất</p>
    </a>
</li>

<li>
    <a href="<?php echo e(route('categorie.index')); ?>">
        <p>Danh mục loại sản phẩm</p>
    </a>
</li>

<li>
    <a href="<?php echo e(route('customer.index')); ?>">
        <p>Danh mục khách hàng</p>
    </a>
</li>

<li>
    <a href="<?php echo e(route('order.index')); ?>">
        <p>Danh mục đơn đặt hàng</p>
    </a>
</li>
</ul>
</div>
<style type="text/css">
    body{
        font-weight: bold;

    </style>
