 <div class="branch leftbar">
              <h3 class="title">
                Branch
              </h3>
              <ul>
              	<?php $__currentLoopData = $brands; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $brands): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              	<li><a href="<?php echo e(route('indexBrands',[$brands->id])); ?>"><?php echo e($brands->name); ?>	</a></li>
              	<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              </ul>
            </div>