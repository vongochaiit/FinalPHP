 <div class="sidebar-wrapper">
        <ul class="nav">
          <li class="active " >
            <a href="<?php echo e(route('product.index')); ?>">
              <i style="color: #000;opacity: .5" class="fa fa-calendar"></i>
              <p style="color: #000;opacity: .5">PRoduct</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('brand.index')); ?>">
              <i class="fa fa-cogs"></i>
              <p >Brand</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('categorie.index')); ?>">
              <i class="fa fa-book"></i>
              <p>categorie</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('customer.index')); ?>">
              <i class="fa fa-fire"></i>
              <p>Customer</p>
            </a>
          </li>
          <li>
            <a href="<?php echo e(route('order.index')); ?>">
              <i class="fa fa-qrcode"></i>
              <p>Order</p>
            </a>
          </li>
          
          
        </ul>
      </div>