<div class="brands_products"><!--brands_products-->
							<h2>Brands</h2>
							<div class="brands-name">
								<ul class="nav nav-pills nav-stacked">
									<li><a href="#"> <span class="pull-right"></span>XIAOMI</a></li>
									<li><a href="#"> <span class="pull-right"></span>SASMUNG</a></li>
									<li><a href="#"> <span class="pull-right"></span>LG</a></li>
									<li><a href="#"> <span class="pull-right"></span>SONY</a></li>
									<li><a href="#"> <span class="pull-right"></span>APPLE</a></li>
									<li><a href="#"> <span class="pull-right"></span>HTC</a></li>
									<li><a href="#"> <span class="pull-right"></span>OPPO</a></li>
								</ul>
							</div>
						</div><!--/brands_products-->
						