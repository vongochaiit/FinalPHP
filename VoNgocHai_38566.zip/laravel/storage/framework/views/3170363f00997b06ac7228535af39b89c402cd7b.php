<?php $__env->startSection('title','Categories'); ?>
<?php $__env->startSection('content'); ?>



<div class="content">
	
	<div class="row">
		
		<?php if(Session::has('thongdiep')): ?>
		<div class="alert alert-primary" role="alert">
			<p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
		</div>
		
		<?php endif; ?>
		<?php if(Session::has('loi')): ?>
		<div class="btn btn-dange" role="alert">
			<p class=""><?php echo e(Session::get('loi')); ?></p>						
		</div>
		
		<?php endif; ?>
		<div class="col-md-12">
			<div class="card "  style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					<a style="margin: 10px;color: black" href="<?php echo e(route('categorie.create')); ?> "class="btn btn-primary">Thêm loại sản phẩm</a>	
					<h5 class="card-title">Danh sách loại sản phẩm</h5>
					
				</div>
				<div class="card-body ">
					<?php echo e(Form::open(['route' => ['categorie.index' ],'method' => 'get'])); ?>

					
					<div class="form-group col-6" style="float: left;">
						<p>Loại sản phẩm</p>
						<?php echo e(Form::text('seacrhName','',['class'=>'form-control ','style'=>'float: left'])); ?>

						
						
						
						
					</div>
					<?php echo e(form::submit('Tiềm kiếm',['class'=>'btn btn-primary','style'=>'margin-top:37px;'])); ?>

					<?php echo e(Form::close()); ?>

					<table class="table ">
						<thead>
							<th style="text-align:center;">STT</th>
							<th style="text-align:center;">Tên loại sản phẩm</th>
							<th style="text-align:center;">Mô tả</th>
							<th >Hành động</th>
						</thead>
						<tbody>

							<?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $categories): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
							<tr>
								<td style="text-align:center;"><?php echo e(++$key); ?></td>
								<td style="text-align:center;"><?php echo e($categories->name); ?></td>	
								<td style="text-align:center;"><?php echo e($categories->description); ?></td>
								<td >

									
									<a href="<?php echo e(route('categorie.edit',$categories->id)); ?>" style="float: left;margin-right: 20px;" class="btn btn-primary">Sữa</a>
									<?php echo e(Form::open(['route' => ['categorie.destroy',$categories->id ],'method' => 'Delete'])); ?>

									<?php echo e(form::submit('Xóa',['class'=>'btn btn-danger','style'=>'float: left'])); ?>

									<?php echo e(Form::close()); ?>

								</tr>
							</tr>

							<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
							
						</tbody>
					</table>
					
				</div>
				
			</div>
		</div>
	</div>
	
</div>

</div>


<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>