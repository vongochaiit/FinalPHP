<?php $__env->startSection('title','Categories'); ?>
<?php $__env->startSection('content'); ?>


		
	<div class="content">
        
        <div class="row">
        	
			<?php if(Session::has('thongdiep')): ?>
					<div class="alert alert-primary" role="alert">
						 <p class=""><?php echo e(Session::get('thongdiep')); ?></p>						
					</div>
				
			<?php endif; ?>
			<?php if(Session::has('loi')): ?>
					<div class="btn btn-dange" role="alert">
						 <p class=""><?php echo e(Session::get('loi')); ?></p>						
					</div>
				
			<?php endif; ?>
          <div class="col-md-12">
            <div class="card ">
              <div class="card-header ">
              	<a style="margin: 10px" href="<?php echo e(route('customer.create')); ?> "class="btn btn-success">Create customer</a>	
                <h5 class="card-title">Customer</h5>
                
              </div>
              <div class="card-body ">
	<table class="table ">
		<thead>
			<th style="text-align:center;">STT</th>
			<th style="text-align:center;">Name</th>
			<th style="text-align:center;">Description</th>
			<th >Action</th>
		</thead>
		<tbody>

			<?php $__currentLoopData = $customers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $customers): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
			<tr>
				<td style="text-align:center;"><?php echo e(++$key); ?></td>
				<td style="text-align:center;"><?php echo e($customers->first_name); ?></td>	
				<td style="text-align:center;"><?php echo e($customers->last_name); ?></td>
				<td >

				
				<a href="<?php echo e(route('customer.edit',$customers->id)); ?>" style="float: left;" class="btn btn-primary">edit</a>
				<?php echo e(Form::open(['route' => ['customer.destroy',$customers->id ],'method' => 'Delete'])); ?>

				<?php echo e(form::submit('Delete',['class'=>'btn btn-danger','style'=>'float: left'])); ?>

				<?php echo e(Form::close()); ?>

			</tr>
			</tr>

			<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			
		</tbody>
	</table>
	
              </div>
              <div class="card-footer ">
                <hr>
                <div class="stats">
                  <i class="fa fa-history"></i> PHP LARAVEL
                </div>
              </div>
            </div>
          </div>
        </div>
      
      </div>
     
    </div>
	

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>