<?php $__env->startSection('title','Brand'); ?>
<?php $__env->startSection('content'); ?>
<div class="content">
    
    <div class="row">
      <div class="col-md-12">
        <div class="card " style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
          <div class="card-header ">
              
            <h5 class="card-title">Chi tiết đơn đặt hàng</h5>
            
        </div>
        <div class="card-body ">
          <div class="row">

			
             </div>
             <div class="box-header with-border">
                <div class="row">
                    <div class="col-md-12">
                        <div class="container123  col-md-6"   style="">
                            <h4></h4>
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th >Thông tin khách hàng</th>
                                        <th ></th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <tr >
                                        <td>Thông tin người đặt hàng</td>
                                        <td ><?php echo e($orders->customers->first_name); ?> <?php echo e($orders->customers->last_name); ?></td>
                                    </tr>
                                    <tr>
                                        <td>Ngày đặt</td>
                                        <td><?php echo e($orders->transaction_date); ?></td>
                                    </tr>
                                    
                                    <tr>
                                        <td>Mã bưu điện</td>
                                        <td ><?php echo e($orders->customers->postal_address); ?> </td>
                                    </tr>
                                    <tr>
                                        <td>Địa chỉ</td>
                                        <td ><?php echo e($orders->customers->physical_address); ?> </td>
                                    </tr>
                                    <tr>
                                        <td>Email</td>
                                        <td ><?php echo e($orders->customers->email); ?> </td>
                                    </tr>
                                    <tr>
                                        <td>Ghi chú</td>
                                        <td > <?php echo e($orders->status); ?></td>
                                        
                                    </tr>
                                </tbody>
                            </table>
                        </div>
                        <table id="myTable" class="table table-bordered table-hover dataTable" role="grid" aria-describedby="example2_info">
                            <thead>
                                <tr role="row">
                                    <th style="text-align: center;" >STT</th>
                                    <th style="text-align: center;">Tên sản phẩm</th>
                                    <th style="text-align: center;">Số lượng</th>
                                    <th style="text-align: center;">Giá tiền</th>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $orders_details; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $orders_details): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                      <td style="text-align: center;"><?php echo e($key+1); ?></td>
                                      <td style="text-align: center;"> <?php echo e($orders_details->product->product_name); ?></td>
                                      <td style="text-align: center;"><?php echo e($orders_details->quantity); ?></td>
                                      <td style="text-align: center;"><?php echo e($orders_details->price); ?></td>
                                  </tr>	   
                                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                  <tr>
                                    <td colspan="3"><b>Tổng tiền</b></td>
                                    <td style="text-align: center;"><?php echo e($orders->total_amount); ?></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                </div>
                <div class="col-md-12">
                    <?php echo e(Form::model($orders,['route' => ['order.update',$orders->id ],'method' => 'put'])); ?>

                    
                    <?php echo e(csrf_field()); ?>

                    <div class="col-md-8"></div>
                    <div class="col-md-4">
                        <div class="form-inline">
                         <p style="padding: 5px 0 0 5px;">Tình trạng</p>
                         <select name="status" class="form-control input-inline" style="width: 200px">
                            <option value="Chưa giao">Chưa giao</option>
                            <option value="Đang giao">Đang giao</option>
                            <option value="Đã giao">Đã giao</option>
                        </select>

                        <input type="submit" value="Xử lý" class="btn btn-primary">
                    </div>
                </div>
                <?php echo e(Form::close()); ?>

            </div>
        </div>
    </div>



    
    
    
</div>
</div>
</div>

</div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>