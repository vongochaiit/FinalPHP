

<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="{{asset('source/images/favicon.png')}}">
  <title>
   Detail 
  </title>
  <link href="{{asset('source/css/bootstrap.css')}}" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,700,500italic,100italic,100' rel='stylesheet' type='text/css'>
  <link href="{{asset('source/css/font-awesome.min.css')}}" rel="stylesheet">
  <link rel="stylesheet" href="{{asset('source/css/flexslider.css')}}" type="text/css" media="screen"/>
  <link href="{{asset('source/css/style.css')}}" rel="stylesheet" type="text/css">
    <!--[if lt IE 9]>
<script src="https://oss.maxcdn.com/libs/html5shiv/3.7.0/html5shiv.js">
</script>
<script src="https://oss.maxcdn.com/libs/respond.js/1.3.0/respond.min.js">
</script>
<![endif]-->
</head>
<body>
  <div class="wrapper">
    <div class="header">
      <div class="container">
        <div class="row">
          <div class="col-md-2 col-sm-2">
            <div class="logo">
              <a href="index.html">
                <img src="{{asset('source/images/logo.png')}}" alt="FlatShop">
              </a>
            </div>
          </div>
          <div class="col-md-10 col-sm-10">
            <div class="header_top">
              <div class="row">
                <div class="col-md-3">
                  <ul class="option_nav">
                 
                    
                  </ul>
                </div>
                <div class="col-md-6">
                  <ul class="topmenu">
                    <li>
                      <a href="#">
                        About Us
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        News
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        Service
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        Recruiment
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        Media
                      </a>
                    </li>
                    <li>
                      <a href="#">
                        Support
                      </a>
                    </li>
                  </ul>
                </div>
                <div class="col-md-3">
                  <ul class="usermenu">
                    <li>
                      <a href="checkout.html" class="log">
                        Login
                      </a>
                    </li>
                    <li>
                      <a href="checkout2.html" class="reg">
                        Register
                      </a>
                    </li>
                  </ul>
                </div>
              </div>
            </div>
            <div class="clearfix">
            </div>
            <div class="header_bottom">
              <ul class="option">
                <li id="search" class="search">
                  <form>
                    <input class="search-submit" type="submit" value="">
                    <input class="search-input" placeholder="Enter your search term..." type="text" value="" name="search">
                  </form>
                </li>
                <li class="option-cart">

                  <a href="{{route('cart.index')}}" class="cart-icon">
                           <p style="color: white;">{{Cart::count()}}</p>
                   
                  </a>
                
                </li>
              </ul>
              <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                  <span class="sr-only">
                    Toggle navigation
                  </span>
                  <span class="icon-bar">
                  </span>
                  <span class="icon-bar">
                  </span>
                  <span class="icon-bar">
                  </span>
                </button>
              </div>
              <div class="navbar-collapse collapse">
                <ul class="nav navbar-nav">
                  <li class="active dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                      Home
                    </a>
                    <div class="dropdown-menu">
                      <ul class="mega-menu-links">
                        <li>
                          <a href="index.html">
                            home
                          </a>
                        </li>
                        <li>
                          <a href="home2.html">
                            home2
                          </a>
                        </li>
                        <li>
                          <a href="home3.html">
                            home3
                          </a>
                        </li>
                        <li>
                          <a href="productlitst.html">
                            Productlitst
                          </a>
                        </li>
                        <li>
                          <a href="productgird.html">
                            Productgird
                          </a>
                        </li>
                        <li>
                          <a href="details.html">
                            Details
                          </a>
                        </li>
                        <li>
                          <a href="cart.html">
                            Cart
                          </a>
                        </li>
                        <li>
                          <a href="checkout.html">
                            CheckOut
                          </a>
                        </li>
                        <li>
                          <a href="checkout2.html">
                            CheckOut2
                          </a>
                        </li>
                        <li>
                          <a href="contact.html">
                            contact
                          </a>
                        </li>
                      </ul>
                    </div>
                  </li>
                  <li>
                    <a href="productgird.html">
                      men
                    </a>
                  </li>
                  <li>
                    <a href="productlitst.html">
                      women
                    </a>
                  </li>
                  <li class="dropdown">
                    <a href="#" class="dropdown-toggle" data-toggle="dropdown">
                      Fashion
                    </a>
                   
                  </li>
                  <li>
                    <a href="productgird.html">
                      gift
                    </a>
                  </li>
                  <li>
                    <a href="productgird.html">
                      kids
                    </a>
                  </li>
                  <li>
                    <a href="productgird.html">
                      blog
                    </a>
                  </li>
                  <li>
                    <a href="productgird.html">
                      jewelry
                    </a>
                  </li>
                  <li>
                    <a href="contact.html">
                      contact us
                    </a>
                  </li>
                </ul>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="clearfix">
      </div>
      <div class="page-index">
        <div class="container">
          <p>
            Home - Products Details
          </p>
        </div>
      </div>
    </div>
    <div class="clearfix">
    </div>
    <div class="container_fullwidth">
      <div class="container">
        <div class="row" >
          <div class="col-md-10">
            <div class="products-details">
              <div class="preview_image">
                <div class="preview-small">
                  <img id="zoom_03" src="{!! asset("/img/$product->images") !!}"  alt="">
                </div>

              </div>
              <!-- detail right -->
              <div class="products-description">
                <h5 class="name">
                  {{$product->product_name}}
                </h5>
              
                <p>
                  Danh mục : 
                  <span class=" light-red">
                    <span>{{$product->categories->name}}
                  </span>
                </p>
                <p>
                  Hãng sản xuất : 
                  <span class=" light-red">
                    <span>{{$product->brands->name}}
                  </span>
                </p>
                <p>
                  Mô tả :
                 {{$product->description}}
                </p>
                <hr class="border">
                <div class="price">
                  Giá : 
                  <span class="new_price">
                   {{$product->price}}
                    <sup>
                      $
                    </sup>
                  </span>

                </div>
                <hr class="border">
                <div class="wided">
                  <div class="qty">
                   <h3 class="title">
             <a href="">  <button >Quay lại</button></a>
           </h3>
                  </div>
                  <div class="button_group">
                    <a href="{{route('addCart',['id'=>$product->id])}}"><button class="button" >
                      Add To Cart
                    </button></a>
                   
                    <button class="button favorite">
                      <i class="fa fa-heart-o">
                      </i>
                    </button>
                    <button class="button favorite">
                      <i class="fa fa-envelope-o">
                      </i>
                    </button>
                  </div>
                </div>


              </div>
              <div class="clearfix">
              </div>



              
            </div>

          </div>
          <div class="clearfix">
          </div>
          <div class="our-brand">
            

         </div>
       </div>
     </div>
     <div class="clearfix">
     </div>
     <div class="footer">
      <div class="footer-info">
        <div class="container">
          <div class="row">
            <div class="col-md-3">
              <div class="footer-logo">
                <a href="#">
                  <img src="images/logo.png" alt="">
                </a>
              </div>
            </div>
            <div class="col-md-3 col-sm-6">
              <h4 class="title">
                Contact 
                <strong>
                  Info
                </strong>
              </h4>
              <p>
                No. 08, Nguyen Trai, Hanoi , Vietnam
              </p>
              <p>
                Call Us : (084) 1900 1008
              </p>
              <p>
                Email : michael@leebros.us
              </p>
            </div>
            <div class="col-md-3 col-sm-6">
              <h4 class="title">
                Customer
                <strong>
                  Support
                </strong>
              </h4>
              <ul class="support">
                <li>
                  <a href="#">
                    FAQ
                  </a>
                </li>
                <li>
                  <a href="#">
                    Payment Option
                  </a>
                </li>
                <li>
                  <a href="#">
                    Booking Tips
                  </a>
                </li>
                <li>
                  <a href="#">
                    Infomation
                  </a>
                </li>
              </ul>
            </div>
            <div class="col-md-3">
              <h4 class="title">
                Get Our 
                <strong>
                  Newsletter 
                </strong>
              </h4>
              <p>
                Lorem ipsum dolor ipsum dolor.
              </p>
              <form class="newsletter">
                <input type="text" name="" placeholder="Type your email....">
                <input type="submit" value="SignUp" class="button">
              </form>
            </div>
          </div>
        </div>
      </div>
      <div class="copyright-info">
        <div class="container">
          <div class="row">
            <div class="col-md-6">
              <p>
                Copyright © 2012. Designed by 
                <a href="#">
                  Michael Lee
                </a>
                . All rights reseved
              </p>
            </div>
            <div class="col-md-6">
              <ul class="social-icon">
                <li>
                  <a href="#" class="linkedin">
                  </a>
                </li>
                <li>
                  <a href="#" class="google-plus">
                  </a>
                </li>
                <li>
                  <a href="#" class="twitter">
                  </a>
                </li>
                <li>
                  <a href="#" class="facebook">
                  </a>
                </li>
              </ul>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
  <!-- Bootstrap core JavaScript==================================================-->
  <script type="text/javascript" src="js/jquery-1.10.2.min.js">
  </script>
  <script type="text/javascript" src="js/bootstrap.min.js">
  </script>
  <script defer src="js/jquery.flexslider.js">
  </script>
  <script type="text/javascript" src="js/jquery.carouFredSel-6.2.1-packed.js">
  </script>
  <script type="text/javascript" src='js/jquery.elevatezoom.js'>
  </script>
  <script type="text/javascript" src="js/script.min.js" >
  </script>
</body>
</html>