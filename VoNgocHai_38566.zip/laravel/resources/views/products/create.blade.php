@extends('layouts.main')
@section('title','Create customer')
@section('content')

<div class="content">

	<div class="row">
		<div class="col-md-12">
			<div class="card "  style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					
					
				</div>
				<div class="card-body ">
					<div class="row">

						@if(Session::has('thongdiep'))
						<div class="alert alert-primary col-12" style="margin: 10px" role="alert">
							<p class="">{{Session::get('thongdiep')}}</p>						
						</div>

						@endif
					</div>

					{{ Form::open(['route' => 'product.store', 'method' => 'post','enctype '=>'multipart/form-data']) }}

					<div class="form-group ">
						<p>Tên sản phẩm:</p>
						{{ Form::text('product_name','',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('product_name')}}</span>
					</div>
					<div class="form-group ">
						<p>Mô tả:</p>
						{{ Form::text('description','',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('description')}}</span>
					</div>
					
					<div class="">
						<p>Chọn hinh sảnh sản phẩm:</p>
						<input  name="images" type="file" class="form-control">
                         <span class="text-danger">{{$errors->first('images')}}</span>

					</div>
					<div class="form-group ">

						<p style="padding-top: 10px;">Giá:</p>
						{{ Form::text('price','',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('price')}}</span>
					</div>
					<div class="form-group ">
						<p>Hãng sản xuất:</p>
						<select class="form-control" name="brand_id">



							@foreach ($brands as $key => $brands)
							<option value="{{$brands->id}}" > 
								{{ $brands->name }} 
							</option>
							@endforeach   
							
						</select>
					</div>
					<div class="form-group ">
						<p>Danh mục:</p>
						<select class="form-control" name="categorie_id">



							@foreach ($categories as $key => $categories)
							<option value="{{$categories->id}}" > 
								{{ $categories->name }} 
							</option>
							@endforeach   

						</select>

					</div>
					{{form::submit('Lưu',['class'=>'btn btn-primary']) }}
					<a style="margin: 10px" href="{{route('product.index')}} "class="btn btn-success">Danh sách </a>
					{{ Form::close() }}
				</div>


				
			</div>
		</div>
	</div>

</div>

</div>
@endsection
