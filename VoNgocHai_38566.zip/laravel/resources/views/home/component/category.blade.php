  <div class="category leftbar">
              <h3 class="title">
                Categories
              </h3>
              <ul>
               	@foreach( $categories as $key => $categories )
				<li><a href="{{route('indexCategories',[$categories->id])}}">{{ $categories->name }}	</a></li>

                @endforeach
              </ul>
            </div>