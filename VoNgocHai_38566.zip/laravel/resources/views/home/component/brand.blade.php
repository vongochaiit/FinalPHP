 <div class="branch leftbar">
              <h3 class="title">
                Branch
              </h3>
              <ul>
              	@foreach( $brands as $key => $brands )
              	<li><a href="{{route('indexBrands',[$brands->id])}}">{{ $brands->name }}	</a></li>
              	@endforeach
              </ul>
            </div>