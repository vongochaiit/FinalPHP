
<div class="row">
                @foreach( $products as $key => $products )
                <div class="col-md-4 col-sm-6">
                  <div class="products">
                    <div class="thumbnail">
                      <a href="{{route('product.chitiet',$products->id)}}">
                        <img src="{!! asset("/img/$products->images") !!}" alt="Product Name">
                      </a>
                    </div>
                    <div class="productname">
                    {{$products->product_name}}
                    </div>
                    <h4 class="price">
                      {{$products->price}}$
                    </h4>
                    <div class="button_group">
                      <a href="{{route('addCart',['id'=>$products->id])}}">
                      <button class="button add-cart" type="button">
                        Add To Cart
                      </button>
                      </a>
                      <button class="button compare" type="button">
                        <i class="fa fa-exchange">
                        </i>
                      </button>
                      <button class="button wishlist" type="button">
                        <i class="fa fa-heart-o">
                        </i>
                      </button>
                    </div>
                  </div>
                </div>
                @endforeach
           
              </div>
