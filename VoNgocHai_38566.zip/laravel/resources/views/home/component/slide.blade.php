 <div class="banner">
              <div class="bannerslide" id="bannerslide">
                <ul class="slides">
                  <li>
                    <a href="#">
                        <img src="source/images/banner-01.jpg" alt=""/>
                    </a>
                  </li>
                  <li>
                    <a href="#">
                        <img src="source/images/banner-02.jpg" alt=""/>
                    </a>
                  </li>
                </ul>
              </div>
            </div>