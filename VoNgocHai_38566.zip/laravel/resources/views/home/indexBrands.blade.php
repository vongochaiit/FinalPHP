<!DOCTYPE html>
<html>
<head>
  <meta http-equiv="Content-Type" content="text/html;charset=utf-8"/>
  <meta name="description" content="">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="shortcut icon" href="source/images/favicon.png">
  <title>
    Welcome to FlatShop
  </title>
  <link href="{{asset('source/css/bootstrap.css')}}" rel="stylesheet">
  <link href='http://fonts.googleapis.com/css?family=Roboto:400,300,300italic,400italic,500,700,500italic,100italic,100' rel='stylesheet' type='text/css'>
  <link href="{{asset('source/css/font-awesome.min.css')}}" rel="stylesheet">
  <link rel="stylesheet" href="{{asset('source/css/flexslider.css')}}" type="text/css" media="screen"/>
  <link href="{{asset('source/css/style.css')}}" rel="stylesheet">
</head>
<body>
  <div class="wrapper">
{{-- header --}}
    @include('home.component.header')
    <div class="clearfix">
    </div>
    <div class="container_fullwidth">
      <div class="container">
        <div class="row">

          <div class="col-md-3">
      {{-- categories --}}
          @include('home.component.category')

            <div class="clearfix">
            </div>
            {{-- brands --}}
            @include('home.component.brand')
            <div class="clearfix">
            </div>
           
           
          </div>
          <div class="col-md-9">
           {{-- slide --}}
           
            <div class="clearfix">
            </div>
            <div class="products-grid">
              <div class="toolbar">
               
               
              </div>
              <div class="clearfix">
              </div>
              {{-- Product --}}
                @include('home.component.product')
              <div class="clearfix">
              </div>
              {{-- List --}}
              <div class="toolbar">
                
              
              </div>
       
            </div>
            <div class="clearfix">
            </div>
          </div>
        </div>
      </div>
      <div class="clearfix">
      </div>
 
    </div>
  </div>
  <div class="clearfix">
  </div>
  {{-- footer --}}
 @include('home.component.footer')
</div>
<script type="text/javascript" src="source/js/jquery-1.10.2.min.js">
</script>
<script type="text/javascript" src="source/js/jquery.easing.1.3.js">
</script>
<script type="text/javascript" src="source/js/bootstrap.min.js">
</script>
<script defer src="source/js/jquery.flexslider.js">
</script>
<script type="text/javascript" src="source/js/jquery.sequence-min.js">
</script>
<script type="text/javascript" src="source/js/jquery.carouFredSel-6.2.1-packed.js">
</script>
<script type="text/javascript" src="source/js/script.min.js" >
</script>
</body>
</html>