	@extends('layouts.main')
	@section('title','Brand')
	@section('content')
	<div class="content">
		
		<div class="row">
			
			
			<div class="col-md-12">
				<div class="card "style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
					<div class="card-header ">
						
						<h5 class="card-title">Danh sách đơn đặt hàng</h5>
						@if(Session::has('thongdiep'))
						<div class="alert alert-primary" role="alert">
							<p class="">{{Session::get('thongdiep')}}</p>						
						</div>
						
						@endif
						@if(Session::has('loi'))
						<div class="btn btn-dange" role="alert">
							<p class="">{{Session::get('loi')}}</p>						
						</div>
						
						@endif
					</div>
					<div class="card-body ">
						
			<table class="table ">
				<thead>
					<th style="text-align:center;">STT</th>
					<th style="text-align:center;">Tên khách hàng </th>
					<th style="text-align:center;">Mã Đặt Hàng</th>
					<th style="text-align:center;">Thành tiền </th>
					<th >Thao tác</th>
				</thead>
				<tbody>
					
					@foreach( $orders as $key => $orders )
					<tr>
						<td style="text-align:center;">{{ ++$key }}</td>
						<td style="text-align:center;"> {{ $orders->customers->last_name }} {{ $orders->customers->first_name }}</td>
						<!-- <td style="text-align:center;">{{ date('d-m-Y', strtotime($orders->order_number))}}</td>	 -->
						<td style="text-align:center;">{{$orders->order_number}}</td>
						<td style="text-align:center;">{{  $orders->total_amount}}</td>
						<td >
							
							
							<a href="{{route('order.show',$orders->id)}}" style="float: left;margin-right: 10px" class="btn btn-primary">Chi tiết</a>
							{{ Form::open(['route' => ['order.destroy',$orders->id ],'method' => 'Delete']) }}
							{{form::submit('Xóa',['class'=>'btn btn-danger','style'=>'float: left']) }}
							{{ Form::close() }}
						</tr>
					</tr>

					@endforeach
					
				</tbody>
			</table>
		</div>
		
	</div>
</div>
</div>

</div>

</div>
@endsection
