 <div class="sidebar-wrapper" >
  <ul class="nav" >
    <li >
      <a href="{{route('product.index')}}">
        <p >Danh mục sản phẩm</p>
    </a>
</li>

<li>
    <a href="{{route('brand.index')}}">
        <p >Danh mục hãng sản xuất</p>
    </a>
</li>

<li>
    <a href="{{route('categorie.index')}}">
        <p>Danh mục loại sản phẩm</p>
    </a>
</li>

<li>
    <a href="{{route('customer.index')}}">
        <p>Danh mục khách hàng</p>
    </a>
</li>

<li>
    <a href="{{route('order.index')}}">
        <p>Danh mục đơn đặt hàng</p>
    </a>
</li>
</ul>
</div>
<style type="text/css">
    body{
        font-weight: bold;

    </style>
