@extends('layouts.main')
@section('title','Categories')
@section('content')



<div class="content">
	
	<div class="row">
		
		@if(Session::has('thongdiep'))
		<div class="alert alert-primary" role="alert">
			<p class="">{{Session::get('thongdiep')}}</p>						
		</div>
		
		@endif
		@if(Session::has('loi'))
		<div class="btn btn-dange" role="alert">
			<p class="">{{Session::get('loi')}}</p>						
		</div>
		
		@endif
		<div class="col-md-12">
			<div class="card "  style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					<a style="margin: 10px;color: black" href="{{route('categorie.create')}} "class="btn btn-primary">Thêm loại sản phẩm</a>	
					<h5 class="card-title">Danh sách loại sản phẩm</h5>
					
				</div>
				<div class="card-body ">
					{{ Form::open(['route' => ['categorie.index' ],'method' => 'get']) }}
					
					<div class="form-group col-6" style="float: left;">
						<p>Loại sản phẩm</p>
						{{ Form::text('seacrhName','',['class'=>'form-control ','style'=>'float: left']) }}
						
						
						
						
					</div>
					{{form::submit('Tiềm kiếm',['class'=>'btn btn-primary','style'=>'margin-top:37px;']) }}
					{{ Form::close() }}
					<table class="table ">
						<thead>
							<th style="text-align:center;">STT</th>
							<th style="text-align:center;">Tên loại sản phẩm</th>
							<th style="text-align:center;">Mô tả</th>
							<th >Hành động</th>
						</thead>
						<tbody>

							@foreach( $categories as $key => $categories )
							<tr>
								<td style="text-align:center;">{{ ++$key }}</td>
								<td style="text-align:center;">{{ $categories->name }}</td>	
								<td style="text-align:center;">{{  $categories->description}}</td>
								<td >

									
									<a href="{{route('categorie.edit',$categories->id)}}" style="float: left;margin-right: 20px;" class="btn btn-primary">Sữa</a>
									{{ Form::open(['route' => ['categorie.destroy',$categories->id ],'method' => 'Delete']) }}
									{{form::submit('Xóa',['class'=>'btn btn-danger','style'=>'float: left']) }}
									{{ Form::close() }}
								</tr>
							</tr>

							@endforeach
							
						</tbody>
					</table>
					
				</div>
				
			</div>
		</div>
	</div>
	
</div>

</div>


@endsection

