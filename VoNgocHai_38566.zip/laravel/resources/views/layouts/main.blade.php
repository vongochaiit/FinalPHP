<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="utf-8" />
  <link rel="apple-touch-icon" sizes="76x76" href="../assets/img/apple-icon.png">
  <link rel="icon" type="image/png" href="../assets/img/favicon.png">
  <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1" />
  <link rel="stylesheet" type="text/css" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/fontawesome.min.css">
  <title>
    Admin
  </title>
  <meta content='width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0, shrink-to-fit=no' name='viewport' />
  <!--     Fonts and icons     -->
  <link href="https://fonts.googleapis.com/css?family=Montserrat:400,700,200" rel="stylesheet" />
  <link href="https://maxcdn.bootstrapcdn.com/font-awesome/latest/css/font-awesome.min.css" rel="stylesheet">
  <!-- CSS Files -->
  <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" >
  <link rel="stylesheet" type="text/css" href="{{asset('css/paper-dashboard.css?v=2.0.0')}}">

  <!-- CSS Just for demo purpose, don't include it in your project -->
  
</head>

<body  >
  <div class="wrapper " >
    <div class="sidebar" data-color="white" data-active-color="danger" >
      <!--
        Tip 1: You can change the color of the sidebar using: data-color="blue | green | orange | red | yellow"
      -->
      <div class="logo" >
        <a  >
          <div class="logo-image-small">
            <img  src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS2RWLJFNJrSkWQMkKPcZFb_YVlUM3dPalVt-4gVLGrSUzQbT00&s">
          </div>
           <a style="text-decoration: none;float: right;padding-top: 10px" href="{{ url('/main/logout') }}">Logout</a>
        </a>
        <a" class="simple-text logo-normal">
        Admin
        

      </a>

    </div>
    @include('shared.menu')

  </div>
  <div class="main-panel"  style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
    <!-- Navbar -->
    <nav class="navbar navbar-expand-lg navbar-absolute fixed-top navbar-transparent">
      <div class="container-fluid">
        <div class="navbar-wrapper">
          <div class="navbar-toggle">
            <button type="button" class="navbar-toggler">
              <span class="navbar-toggler-bar bar1"></span>
              <span class="navbar-toggler-bar bar2"></span>
              <span class="navbar-toggler-bar bar3"></span>
            </button>
          </div>
          <a class="navbar-brand" href="#pablo"><span >E</span>-SHOPPER</a>
        </div>
        
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navigation">
        <form>
         
          
        </form>

      </div>
    </div>
  </nav>
  
  @yield('content')

</div>



</body>

</html>
