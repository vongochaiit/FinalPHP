@extends('layouts.main')
@section('title','Create customer')
@section('content')

<div class="content">
	
	<div class="row">
		<div class="col-md-12">
			<div class="card " style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					
					
				</div>
				<div class="card-body ">
					<div class="row">

						@if(Session::has('thongdiep'))
						<div class="alert alert-primary col-12" style="margin: 10px" role="alert">
							<p class="">{{Session::get('thongdiep')}}</p>						
						</div>
						
						@endif
					</div>
					{{ Form::model($customers,['route' => ['customer.update',$customers->id ],'method' => 'put']) }}
					<div class="form-group ">
						<p>Họ:</p>
						{{ Form::text('first_name',$customers->first_name,['class'=>'form-control']) }}
						
					</div>
					<div class="form-group {{ $errors->has('fullname') ?'has-error':'' }}">
						<p>Tên:</p>
						{{ Form::text('last_name',$customers->last_name,['class'=>'form-control']) }}
						
					</div>
					<div class="form-group">
						<p>Email:</p>
						{{ Form::text('email',$customers->email,['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('name')}}</span>
					</div>
					<div class="form-group {{ $errors->has('phone') ?'has-error':'' }}">
						
						<p>Mã bưu điện:</p>
						{{ Form::text('postal_address',$customers->postal_address,['class'=>'form-control']) }}
						
					</div>
					<div class="form-group ">
						
						<p>Địa chỉ:</p>
						{{ Form::text('physical_address',$customers->physical_address,['class'=>'form-control']) }}
						
					</div>
					
					{{form::submit('Cập nhật	',['class'=>'btn btn-primary']) }}
					<a style="margin: 10px" href="{{route('customer.index')}} "class="btn btn-success">Trợ lại</a>
					{{ Form::close() }}
				</div>


				
				
				
			</div>
		</div>
	</div>
	
</div>

</div>
@endsection

