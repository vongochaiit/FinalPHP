@extends('layouts.main')
@section('title','Categories')
@section('content')



<div class="content">
	
	<div class="row">
		
		@if(Session::has('thongdiep'))
		<div class="alert alert-primary" role="alert">
			<p class="">{{Session::get('thongdiep')}}</p>						
		</div>
		
		@endif
		@if(Session::has('loi'))
		<div class="btn btn-dange" role="alert">
			<p class="">{{Session::get('loi')}}</p>						
		</div>
		
		@endif
		<div class="col-md-12">
			<div class="card "style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
						
					<h5 class="card-title">Danh sách khách hàng</h5>
					
				</div>
				<div class="card-body ">
					{{ Form::open(['route' => ['customer.index' ],'method' => 'get']) }}
					
					<div class="form-group col-6" style="float: left;">
						<p>Tên khách hàng:</p>
						{{ Form::text('searchName','',['class'=>'form-control ','style'=>'float: left']) }}
					</div>
					{{form::submit('Tìm kiếm',['class'=>'btn btn-primary','style'=>'margin-top:37px;']) }}
					{{ Form::close() }}
					<table class="table ">
						<thead>
							<th style="text-align:center;">STT</th>
							<th style="text-align:center;">Họ</th>
							<th style="text-align:center;">Tên</th>
							<th style="text-align:center;">Email</th>
							<th style="text-align:center;">Mã bưu điện</th>
							<th style="text-align:center;">Địa chỉ</th>
							<th >Hành động</th>
						</thead>
						<tbody>

							@foreach( $customers as $key => $customers )
							<tr>
								<td style="text-align:center;">{{ ++$key }}</td>
								<td style="text-align:center;">{{ $customers->first_name }}</td>	
								<td style="text-align:center;">{{  $customers->last_name}}</td>
								<td style="text-align:center;">{{  $customers->email}}</td>
								<td style="text-align:center;">{{  $customers->postal_address}}</td>
								<td style="text-align:center;">{{  $customers->physical_address}}</td>
								<td >

									
								
									{{ Form::open(['route' => ['customer.destroy',$customers->id ],'method' => 'Delete']) }}
									{{form::submit('Xóa',['class'=>'btn btn-danger','style'=>'margin-left: 15px']) }}
									{{ Form::close() }}
								</tr>
							</tr>

							@endforeach
							
						</tbody>
					</table>
					
				</div>
				
			</div>
		</div>
	</div>
	
</div>

</div>


@endsection
