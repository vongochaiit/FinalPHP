@extends('layouts.main')
@section('title','Create customer')
@section('content')

<div class="content">
	
	<div class="row">
		<div class="col-md-12">
			<div class="card " style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					{{-- <a style="margin: 10px" href="{{route('product.create')}} "class="btn btn-success">Thêm khách hàng</a>	 --}}
					<h5 class="card-title">Thêm khách hàng</h5>
					
				</div>
				<div class="card-body ">
					<div class="row">

						@if(Session::has('thongdiep'))
						<div class="alert alert-primary col-12" style="margin: 10px" role="alert">
							<p class="">{{Session::get('thongdiep')}}</p>						
						</div>
						
						@endif
					</div>
					{{ Form::open(['route' => 'customer.store', 'method' => 'post']) }}
					<div class="form-group ">
						<p>Họ :</p>
						{{ Form::text('first_name','',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('first_name')}}</span>
					</div>
					<div class="form-group ">
					<p>Tên :</p>
						{{ Form::text('last_name','',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('last_name')}}</span>
					</div>
					<div class="form-group ">
					<p>Email :</p>
						{{ Form::text('email','',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('email')}}</span>
					</div>
					<div class="form-group ">
					<p>Tài khoản :</p>
						{{ Form::text('name','',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('name')}}</span>
					</div>

					<div class="form-group ">
						<p>Mật khẩu :</p>
						{{ Form::password('password',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('password')}}</span>
					</div>

					<div class="form-group ">
						
						<p>Mã bưu điện :</p>
						{{ Form::text('postal_address','',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('postal_address')}}</span>
					</div>
					<div class="form-group ">
						
						<p>Địa chỉ :</p>
						{{ Form::text('physical_address','',['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('physical_address')}}</span>
					</div>
					
					{{form::submit('Thêm',['class'=>'btn btn-primary']) }}
					<a style="margin: 10px" href="{{route('customer.index')}} "class="btn btn-success">Trở lại</a>
					{{ Form::close() }}
				</div>
				
			
			</div>
		</div>
	</div>
	
</div>

</div>
@endsection
