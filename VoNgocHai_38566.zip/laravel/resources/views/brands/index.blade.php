@extends('layouts.main')
@section('title','Brand')
@section('content')



<div class="content">
	
	<div class="row">
		
		@if(Session::has('thongdiep'))
		<div class="alert alert-primary" role="alert">
			<p class="">{{Session::get('thongdiep')}}</p>						
		</div>
		
		@endif
		@if(Session::has('loi'))
		<div class="btn btn-dange" role="alert">
			<p class="">{{Session::get('loi')}}</p>						
		</div>
		
		@endif
		<div class="col-md-12">
			<div class="card " style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					<a style="margin: 10px;color: black; " href="{{route('brand.create')}} "class="btn btn-primary" >Thêm hãng sản xuất	</a>	
					<h5 class="card-title">Danh sách hãng sản xuất</h5>
					
				</div>
				<div class="card-body ">
					{{ Form::open(['route' => ['brand.index' ],'method' => 'get']) }}
					
					<div class="form-group col-6" style="float: left;">
						<p>Hãng sản xuất:</p>
						{{ Form::text('searchName','',['class'=>'form-control ','style'=>'float: left']) }}
					</div>
					{{form::submit('Tìm kiếm',['class'=>'btn btn-primary','style'=>'margin-top:37px;']) }}
					{{ Form::close() }}
					<table class="table ">
						<thead>
							<th style="text-align:center;">STT</th>
							<th style="text-align:center;">Hãng sản xuất</th>
							<th style="text-align:center;">Mô tả</th>
							<th >Hành động</th>
						</thead>
						<tbody>
							
							@foreach( $brands as $key => $brands )
							<tr>
								<td style="text-align:center;">{{ ++$key }}</td>
								<td style="text-align:center;">{{ $brands->name }}</td>	
								<td style="text-align:center;">{{  $brands->description}}</td>
								<td >

									{{-- <a href="{{route('brand.show',$brands->id)}}" style="float: left;margin-right: 10px" class="btn btn-primary">Chi tiết</a> --}}
									<a href="{{route('brand.edit',$brands->id)}}" style="float: left;margin-right: 20px" class="btn btn-primary">Sữa</a>
									{{ Form::open(['route' => ['brand.destroy',$brands->id ],'method' => 'Delete']) }}
									{{form::submit('Xóa',['class'=>'btn btn-danger','style'=>'float: left']) }}
									{{ Form::close() }}
								</tr>
							</tr>

							@endforeach
							
						</tbody>
					</table>
				</div>
				
			</div>
		</div>
	</div>
	
</div>

</div>

@endsection
