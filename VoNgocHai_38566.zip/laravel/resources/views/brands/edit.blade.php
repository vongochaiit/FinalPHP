@extends('layouts.main')
@section('title','Create brand')
@section('content')

<div class="content">
	
	<div class="row">
		<div class="col-md-12">
			<div class="card " style="background-image: linear-gradient(#D3CCE3, #E9E4F0);">
				<div class="card-header ">
					
					
				</div>
				<div class="card-body ">
					<div class="row">

						@if(Session::has('thongdiep'))
						<div class="alert alert-primary col-12" style="margin: 10px" role="alert">
							<p class="">{{Session::get('thongdiep')}}</p>						
						</div>
						
						@endif
					</div>
					
					
					
					{{ Form::model($brands,['route' => ['brand.update',$brands->id ],'method' => 'put']) }}
					<div class="form-group ">
						<p>Hãng sản xuất:</p>
						{{ Form::text('name',$brands->name,['class'=>'form-control']) }}
						
					</div>
					<div class="form-group ">
						
						<p>Mô tả:</p>
						{{ Form::text('description',$brands->description,['class'=>'form-control']) }}
						<span class="text-danger">{{$errors->first('phone')}}</span>
					</div>
					
					{{form::submit('Cập nhật',['class'=>'btn btn-primary']) }}
					<a style="margin: 10px" href="{{route('brand.index')}} "class="btn btn-success">Trở lại </a>
					{{ Form::close() }}
				</div>


				
				
				
			</div>
		</div>
	</div>
	
</div>

</div>
@endsection